# project/test.py

import unittest


class TestConfiguration(unittest.TestCase):

    def test_configuration(self):
        pass

if __name__ == '__main__':
    unittest.main()