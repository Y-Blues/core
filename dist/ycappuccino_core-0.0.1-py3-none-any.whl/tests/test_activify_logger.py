# project/test.py

import unittest


class TestLogger(unittest.TestCase):

    def test_logger(self):
        pass

if __name__ == '__main__':
    unittest.main()