# project/test.py

import unittest

class TestProxy(unittest.TestCase):

    def test_unit(self):
        pass

if __name__ == '__main__':
    unittest.main()